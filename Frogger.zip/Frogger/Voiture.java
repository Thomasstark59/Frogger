package Frogger;

public abstract class Voiture 
{
	int vitesseBasique = 0;
	int positionY = 0;
	int positionX = 0;
	public Voiture()
	{
		
	}
	public Voiture(int speed, int x, int y)
	{
		this.positionX = x;
		this.positionY = y;
		this.vitesseBasique = speed;
	}
	public int getVitesse() {
		return vitesseBasique;
	}
	public void setVitesse(int vitesse) 
	{
		this.vitesseBasique = vitesse;
	}
	public int getPositionY() {
		return positionY;
	}
	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}
	public int getPositionX() {
		return positionX;
	}
	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}
	public void move ()
	{
		
	}
}

package Frogger;

public class Frog 
{
    private int [] defaultFrogSpawn = {400,800};
    public Frog()
    {
    	
    }
	public int getDefaultFrogSpawnX() 
	{
		return defaultFrogSpawn[0];
	}
	public int getDefaultFrogSpawnY() 
	{
		return defaultFrogSpawn[1];
	}

	public void setDefaultFrogSpawnX(int defaultFrogSpawnX) 
	{
		this.defaultFrogSpawn[0] = defaultFrogSpawnX;
	}
	public void setDefaultFrogSpawnY(int defaultFrogSpawnY) 
	{
		this.defaultFrogSpawn[1] = defaultFrogSpawnY;
	}
}

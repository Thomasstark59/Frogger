package Frogger;

public class VoitureRouge extends Voiture 
{
    private int [] defaultRedCarSpawn = {800,700};
    private int speedBoostValue = 3;
    public VoitureRouge()
    {
    	
    }
    public VoitureRouge(int[] defaultRedCarSpawn) 
	{
		super();
		this.defaultRedCarSpawn = defaultRedCarSpawn;
	}
	public void speedBoost()
	{
		int temp = getVitesse();
		temp += speedBoostValue;
		setVitesse(temp);
	}
	public int getDefaultRedCarSpawnX() 
	{
		return defaultRedCarSpawn[0];
	}
	public int getDefaultRedCarSpawnY() 
	{
		return defaultRedCarSpawn[1];
	}

	public void setDefaultRedCarSpawnX(int defaultRedCarSpawnX) 
	{
		this.defaultRedCarSpawn[0] = defaultRedCarSpawnX;
	}
	public void setDefaultYellowCarSpawnY(int defaultRedCarSpawnY) 
	{
		this.defaultRedCarSpawn[1] = defaultRedCarSpawnY;
	}
	public void move ()
	{
		
	}
}

package Frogger;

public class VoitureBleu extends Voiture 
{
    private int [] defaultBlueCarSpawn = {800,500};
	private int speedBoostValue;

    public VoitureBleu()
    {
    	
    }
    public VoitureBleu(int[] defaultBlueCarSpawn) 
	{
		super();
		this.defaultBlueCarSpawn = defaultBlueCarSpawn;
	}
	public void speedBoost()
	{
		int temp = getVitesse();
		temp += speedBoostValue;
		setVitesse(temp);
	}
	public int getDefaultBlueCarSpawnX() 
	{
		return defaultBlueCarSpawn[0];
	}
	public int getDefaultBlueCarSpawnY() 
	{
		return defaultBlueCarSpawn[1];
	}

	public void setDefaultBlueCarSpawnX(int defaultBlueCarSpawnX) 
	{
		this.defaultBlueCarSpawn[0] = defaultBlueCarSpawnX;
	}
	public void setDefaultYellowCarSpawnY(int defaultBlueCarSpawnY) 
	{
		this.defaultBlueCarSpawn[1] = defaultBlueCarSpawnY;
	}
	public void move ()
	{
		
	}
}

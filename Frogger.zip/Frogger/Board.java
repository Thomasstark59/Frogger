package Frogger;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.HashMap;

public class Board extends JPanel implements ActionListener {

    private final int B_WIDTH = 900;
    private final int B_HEIGHT = 900;
    private final int DOT_SIZE = 100;
    private final int RAND_POS = 8;
    private final int DELAY = 140;
    private final int JUMP = 100;

    private int pos_x;
    private int pos_y;
    
    private int coinCounter;
    private int insectCounter;

    private ArrayList<FixedGameElement> fixedGameElementList ;
    HashMap<String, ImageIcon> fixedGameElementImageMap ;

    private boolean leftDirection = false;
    private boolean rightDirection = false;
    private boolean upDirection = false;
    private boolean downDirection = false;
    private boolean inGame = true;

    private Timer timer;
    private Image ball;
    private Image coin;
    private Image head;
    private Image board;
    private Image voitureJaune;
    private Image voitureRouge;
    private Image voitureBleu;
    
    private int [] defaultbBoardSpawn = {0,0};

    private int score;
    private int void_x = -1*B_WIDTH;
    private int void_y = -1*B_HEIGHT;

    private VoitureRouge voitureRougeObj = new VoitureRouge();
    private VoitureBleu voitureBleuObj = new VoitureBleu();
    private VoitureJaune voitureJauneObj = new VoitureJaune();
    private Frog frog = new Frog();
    
    public Board() {
        
        initBoard();
    }
    
    private void initBoard() {

        addKeyListener(new TAdapter());
        setBackground(Color.white);
        setFocusable(true);

        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
        loadImages();
        initGame();
    }

    private void loadImages() {
    
        fixedGameElementImageMap = new HashMap<String, ImageIcon>();

        ImageIcon iic = new ImageIcon(Coin.getPathToImage());
        //coinImage = iic.getImage();
        fixedGameElementImageMap.put("coin", iic);
        
        ImageIcon iii = new ImageIcon(Insect.getPathToImage());
        //insectImage = iii.getImage();
        fixedGameElementImageMap.put("insect", iii);
        
        ImageIcon iib = new ImageIcon("D:\\Common\\soft\\eclipse-workspace\\board.png");
        board = iib.getImage();
        
        ImageIcon iih = new ImageIcon("D:\\Common\\soft\\eclipse-workspace\\frogger.png");
        head = iih.getImage();

        ImageIcon iivr = new ImageIcon("D:\\Common\\soft\\eclipse-workspace\\redCar.png");
        voitureRouge = iivr.getImage();
        
        ImageIcon iivb = new ImageIcon("D:\\Common\\soft\\eclipse-workspace\\blueCar.png");
        voitureBleu = iivb.getImage();
        
        ImageIcon iivj = new ImageIcon("D:\\Common\\soft\\eclipse-workspace\\yellowCar.png");
        voitureJaune = iivj.getImage();
        
    }

    private void initGame() {
        
        score = 0 ;
        
        pos_x = B_WIDTH/2;
        pos_y = B_HEIGHT/2;
        
        coinCounter = 3;
        insectCounter = 2;
        fixedGameElementList = new ArrayList<FixedGameElement>();
        
        for(int i = 0; i < coinCounter ; i++){
            fixedGameElementList.add(new Coin(getRandomCoordinate(), getRandomCoordinate()));
        }
        
        for(int i = 0; i < insectCounter ; i++){
            fixedGameElementList.add(new Insect(getRandomCoordinate(), getRandomCoordinate()));
        }
        
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        doDrawing(g);
    }
    
    private void doDrawing(Graphics g) {
        
        if (inGame) {

                 
            g.drawImage(board, defaultbBoardSpawn[0], defaultbBoardSpawn[1], this);
            g.drawImage(head, frog.getDefaultFrogSpawnX(), frog.getDefaultFrogSpawnY(), this);
            g.drawImage(voitureBleu, voitureBleuObj.getDefaultBlueCarSpawnX(), voitureBleuObj.getDefaultBlueCarSpawnY(), this);
            g.drawImage(voitureJaune, voitureJauneObj.getDefaultYellowCarSpawnX(), voitureJauneObj.getDefaultYellowCarSpawnY(), this);
            g.drawImage(voitureRouge, voitureRougeObj.getDefaultRedCarSpawnX(), voitureRougeObj.getDefaultRedCarSpawnY() , this);
            
            for(FixedGameElement elem: fixedGameElementList){               
                g.drawImage(fixedGameElementImageMap.get(elem.getType()).getImage(), elem.getPosX(), elem.getPosY(), this);

            } 
            Toolkit.getDefaultToolkit().sync();
        } 
        else if(coinCounter == 0 && frog.getDefaultFrogSpawnY() == 800 && inGame)
        {
        	win(g);
        	System.out.println("prout");
        }
        else 
        {
            gameOver(g);
        }        
    }

    private void gameOver(Graphics g) {
        
        String msg = "Game Over";
        String scoreTxt = "Score de votre partie : " + score;
        Font small = new Font("Helvetica", Font.BOLD, 14);
        FontMetrics metr = getFontMetrics(small);
        FontMetrics metr2 = getFontMetrics(small);

        
        g.setColor(Color.black);
        g.setFont(small);
        g.drawString(msg, (B_WIDTH - metr.stringWidth(msg)) / 2, B_HEIGHT / 2);
        g.drawString(scoreTxt, (B_WIDTH - metr2.stringWidth(scoreTxt)) / 2, B_HEIGHT / 3);

    }
    private void win(Graphics g) 
    {
        String msg = "win";
        String scoreTxt = "Score de votre partie : " + score;
        Font small = new Font("Helvetica", Font.BOLD, 14);
        FontMetrics metr = getFontMetrics(small);
        FontMetrics metr2 = getFontMetrics(small);

        
        g.setColor(Color.black);
        g.setFont(small);
        g.drawString(msg, (B_WIDTH - metr.stringWidth(msg)) / 2, B_HEIGHT / 2);
        g.drawString(scoreTxt, (B_WIDTH - metr2.stringWidth(scoreTxt)) / 2, B_HEIGHT / 3);
	}

    private void checkFixedGameElementCollision() {

        for(FixedGameElement elem: fixedGameElementList){
            if ((frog.getDefaultFrogSpawnX()== elem.getPosX()) && (frog.getDefaultFrogSpawnY()== elem.getPosY())){
                elem.setPosX(void_x);
                elem.setPosY(void_y);
                
                elem.triggerAction(this);
                
            }
        }    
    }
    
    public void incScore(int valueToIncrease){
        score += valueToIncrease;
    } 
    
    public void decreaseCoinAmount(){
        coinCounter -=1;
    }

    private void move() {
    	
        if (leftDirection) {
        	frog.setDefaultFrogSpawnX(frog.getDefaultFrogSpawnX() - JUMP);
        }

        if (rightDirection) {
        	frog.setDefaultFrogSpawnX(frog.getDefaultFrogSpawnX() + JUMP);
        }

        if (upDirection) {
        	frog.setDefaultFrogSpawnY(frog.getDefaultFrogSpawnY() - JUMP);

        }

        if (downDirection) {
        	frog.setDefaultFrogSpawnY(frog.getDefaultFrogSpawnY() + JUMP);
        }
    }

    private void checkCollision() {

        if (frog.getDefaultFrogSpawnY() >= B_HEIGHT) {
            inGame = false;
        }

        if (frog.getDefaultFrogSpawnY() < 0) {
            inGame = false;
        }

        if (frog.getDefaultFrogSpawnX() >= B_WIDTH) {
            inGame = false;
        }

        if (frog.getDefaultFrogSpawnX() < 0) {
            inGame = false;
        }
        
        if (!inGame) {
            timer.stop();
        }
    }
    
    private int getRandomCoordinate() {

        int r = (int) (Math.random() * RAND_POS);
        return ((r * DOT_SIZE));
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (inGame) {

            checkFixedGameElementCollision();
            checkCollision();
            System.out.println(coinCounter);
            
        }

        repaint();
    }


	private class TAdapter extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {

            int key = e.getKeyCode();

            if (key == KeyEvent.VK_LEFT) {
                leftDirection = true;
                rightDirection = false;
                upDirection = false;
                downDirection = false;
            }

            if (key == KeyEvent.VK_RIGHT){
                leftDirection = false;
                rightDirection = true;
                upDirection = false;
                downDirection = false;
            }

            if (key == KeyEvent.VK_UP){
                leftDirection = false;
                rightDirection = false;
                upDirection = true;
                downDirection = false;
            }

            if (key == KeyEvent.VK_DOWN){
                leftDirection = false;
                rightDirection = false;
                upDirection = false;
                downDirection = true;
            }
            move();
        }
    }
}

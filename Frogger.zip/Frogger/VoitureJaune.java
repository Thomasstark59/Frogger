package Frogger;

public class VoitureJaune extends Voiture 
{
    private int [] defaultYellowCarSpawn = {800,600};
    private int speedBoostValue = 1;

	public VoitureJaune(int[] defaultYellowCarSpawn) 
	{
		super();
		this.defaultYellowCarSpawn = defaultYellowCarSpawn;
	}
	public VoitureJaune()
	{
		
	}
	public void speedBoost()
	{
		int temp = getVitesse();
		temp += speedBoostValue;
		setVitesse(temp);
	}
	public int getDefaultYellowCarSpawnX() 
	{
		return defaultYellowCarSpawn[0];
	}
	public int getDefaultYellowCarSpawnY() 
	{
		return defaultYellowCarSpawn[1];
	}

	public void setDefaultYellowCarSpawnX(int defaultYellowCarSpawnX) 
	{
		this.defaultYellowCarSpawn[0] = defaultYellowCarSpawnX;
	}
	public void setDefaultYellowCarSpawnY(int defaultYellowCarSpawnY) 
	{
		this.defaultYellowCarSpawn[1] = defaultYellowCarSpawnY;
	}
	public void move ()
	{
		
	}
}
